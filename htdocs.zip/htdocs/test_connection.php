<?php

require_once "backend/config/database.php";

echo "Database connection successful!";

?>
