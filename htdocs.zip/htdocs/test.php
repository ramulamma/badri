<?php

echo "Adaptive Online Exam Backend is Working!";

?>